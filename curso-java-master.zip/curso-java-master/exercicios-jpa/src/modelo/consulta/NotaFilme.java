package modelo.consulta;

public class NotaFilme {

	private double media;

	public NotaFilme(double media) {
		super();
		this.media = media;
	}

	public double getMedia() {
		return media;
	}

	public void setMedia(double media) {
		this.media = media;
	}
}
