package generics;

public class CaixaNumero<N extends Number> extends Caixa<N> {

}
