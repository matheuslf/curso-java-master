package oo.heranca.desafio;

public class Civic extends Carro {

	public Civic() {
		super(212);
	}
}
