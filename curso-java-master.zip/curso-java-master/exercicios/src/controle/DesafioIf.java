package controle;

public class DesafioIf {

	public static void main(String[] args) {

		double nota = 1.3;

		// não usar ;  em estruturas de controle (tem um exceção)
		if (nota >= 9.0) {
			System.out.println("Quadro de Honra!");
			System.out.println("Você é fera!!!");
		}
	}
}
