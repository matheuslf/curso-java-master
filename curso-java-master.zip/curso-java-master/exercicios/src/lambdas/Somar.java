package lambdas;

public class Somar implements Calculo {

	public double executar(double a, double b) {	
		return a + b;
	}
}
