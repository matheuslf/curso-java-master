package tela;

public class TelaPrincipal {

	// Tudo começa a partir de um MAIN!!!!
	public static void main(String[] args) {
		
	}
}
