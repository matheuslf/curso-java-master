package pessoa;

public class Funcionario {

}
