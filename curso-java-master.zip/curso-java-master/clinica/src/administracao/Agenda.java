package administracao;

public class Agenda {

}
